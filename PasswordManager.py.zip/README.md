# Password-Management-System
*** 

## Introduction
***
This is a simple and simple and secure Password Management System made completely in Python.

![](https://user-images.githubusercontent.com/60814508/145575095-f08497d0-ce04-4d78-9d8b-4836d6be8950.png)

![](https://user-images.githubusercontent.com/60814508/145575104-60796e75-e4e0-4ac7-8794-ce261c2fccfc.png)


## Required Modules
***

This Python Project uses the following dependencies:

1. PyQty Module (PyQt5 for Python3.6)
2. sqlite3

## Features
***

The entire program is authenticated with one Global Password - so you don't have to remember individual passwords of your accounts, just remember one - and we'll take care of the rest.

## Source Code
***

The entire source code of the program is stored [here](https://github.com/ankit1509/password-Management-System). Feel free to modify/reuse as you like. Make sure you credit me somewhere, though.

## Contribution
***

Everyone is welcome to contribute to this project and build more functionality into it. Make a fork, improve/fix it and create a pull request. I'd love it! :) Also, I'll be mentioning your names over here!
***
***


## -By Dev [Ankit Choudhary](https://github.com/ankit1509)
